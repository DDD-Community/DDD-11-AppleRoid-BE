import { Controller } from '@nestjs/common';

@Controller('posts')
export class PostsReactionController {
  constructor() {}
}
