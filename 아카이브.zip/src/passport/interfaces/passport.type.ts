export enum PassportProviderType {
  PHONE = 'PHONE',
  KAKAO = 'KAKAO',
  NAVER = 'NAVER',
}
