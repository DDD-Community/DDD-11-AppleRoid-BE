export const EMAIL_REGEX = `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`;
