export enum REACTION_TYPE {
  LIKE = 'LIKE',
  DISLIKE = 'DISLIKE',
}
